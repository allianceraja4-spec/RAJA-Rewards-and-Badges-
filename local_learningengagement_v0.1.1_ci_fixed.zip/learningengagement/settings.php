<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $ADMIN->add('localplugins', new admin_externalpage(
        'local_learningengagement_rules',
        get_string('managerules', 'local_learningengagement'),
        new moodle_url('/local/learningengagement/rules.php')
    ));
}
