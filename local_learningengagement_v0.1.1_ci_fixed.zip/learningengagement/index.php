<?php
require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();

$PAGE->set_url(new moodle_url('/local/learningengagement/index.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('dashboard', 'local_learningengagement'));
$PAGE->set_heading(get_string('dashboard', 'local_learningengagement'));

global $DB, $USER;

$transactions = $DB->get_records('local_learningengagement_txn', ['userid' => $USER->id], 'timecreated DESC', '*', 0, 50);
$total = (int)$DB->get_field_sql(
    'SELECT COALESCE(SUM(points),0) FROM {local_le_txn} WHERE userid = ?',
    [$USER->id]
);

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('mypoints', 'local_learningengagement') . ': ' . $total);

$table = new html_table();
$table->head = [
    get_string('activity', 'local_learningengagement'),
    get_string('points', 'local_learningengagement'),
    get_string('date', 'local_learningengagement')
];

foreach ($transactions as $txn) {
    $table->data[] = [
        s($txn->rulecode),
        (int)$txn->points,
        userdate($txn->timecreated)
    ];
}
echo html_writer::table($table);
echo $OUTPUT->footer();
