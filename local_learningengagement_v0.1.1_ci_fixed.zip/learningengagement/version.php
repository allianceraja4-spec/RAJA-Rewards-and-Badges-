<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_learningengagement';
$plugin->version   = 2026072701;
$plugin->requires  = 2024042200; // Moodle 4.4+
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.1';
