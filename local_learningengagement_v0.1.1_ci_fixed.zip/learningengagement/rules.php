<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

admin_externalpage_setup('local_learningengagement_rules');
require_capability('moodle/site:config', context_system::instance());

global $DB;

if (optional_param('seed', 0, PARAM_BOOL) && confirm_sesskey()) {
    $rules = [
        ['course_access', 'Course Access', 5, 3, 'Orientation'],
        ['lesson_access', 'Lesson Access', 10, 5, 'Core Learning'],
        ['learning_material', 'Learning Material', 8, 5, 'Core Learning'],
        ['recall_quiz', 'Recall Quiz', 15, 5, 'Assessment'],
        ['assignment_submission', 'Assignment Submission', 25, 5, 'Assessment'],
        ['module_assessment', 'Assessment (Module)', 30, 5, 'Assessment'],
        ['exam_top10', 'Exam Results (Top 10%)', 100, 5, 'Academic Excellence'],
        ['login_streak_7', 'Login Streak (7-day)', 20, 4, 'Consistency'],
        ['forum_participation', 'Forum Participation', 12, 4, 'Social Learning'],
        ['live_class', 'Live Class Attendance', 15, 3, 'Engagement'],
        ['recorded_video', 'Recorded Videos', 6, 3, 'Core Learning'],
        ['peer_communication', 'Communication (Peer)', 8, 3, 'Social Learning'],
        ['syllabus_view', 'Syllabus View', 5, 3, 'Orientation'],
        ['digital_library', 'Digital Library', 7, 3, 'Self-Directed Learning'],
        ['profile_completion', 'Profile Completion', 10, 2, 'Onboarding'],
    ];
    foreach ($rules as $r) {
        if (!$DB->record_exists('local_learningengagement_rules', ['code' => $r[0]])) {
            $DB->insert_record('local_learningengagement_rules', (object)[
                'code'=>$r[0], 'name'=>$r[1], 'points'=>$r[2],
                'weight'=>$r[3], 'category'=>$r[4], 'enabled'=>1, 'timecreated'=>time()
            ]);
        }
    }
    redirect($PAGE->url, get_string('rulesseeded', 'local_learningengagement'));
}

$rules = $DB->get_records('local_learningengagement_rules', [], 'weight DESC, name ASC');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('managerules', 'local_learningengagement'));
echo html_writer::link(
    new moodle_url($PAGE->url, ['seed'=>1, 'sesskey'=>sesskey()]),
    get_string('seedrules', 'local_learningengagement'),
    ['class'=>'btn btn-primary mb-3']
);

$table = new html_table();
$table->head = ['Activity', 'Weight', 'Points', 'Category', 'Enabled'];
foreach ($rules as $rule) {
    $table->data[] = [
        s($rule->name), (int)$rule->weight, (int)$rule->points,
        s($rule->category), $rule->enabled ? 'Yes' : 'No'
    ];
}
echo html_writer::table($table);
echo $OUTPUT->footer();
