<?php
$string['pluginname'] = 'Learning Engagement Points';
$string['dashboard'] = 'Learning Engagement Dashboard';
$string['mypoints'] = 'My Points';
$string['activity'] = 'Activity';
$string['points'] = 'Points';
$string['date'] = 'Date';
$string['managerules'] = 'Learning Engagement Rules';
$string['seedrules'] = 'Create default scoring rules';
$string['rulesseeded'] = 'Default scoring rules created.';
$string['learningengagement:viewown'] = 'View own engagement points';
$string['learningengagement:viewall'] = 'View all engagement points';
