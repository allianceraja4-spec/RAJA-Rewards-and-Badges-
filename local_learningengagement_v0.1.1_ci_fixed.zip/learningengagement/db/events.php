<?php
defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname' => '\core\event\course_viewed',
        'callback'  => '\local_learningengagement\observer::course_viewed',
    ],
    [
        'eventname' => '\core\event\course_module_viewed',
        'callback'  => '\local_learningengagement\observer::module_viewed',
    ],
    [
        'eventname' => '\mod_assign\event\assessable_submitted',
        'callback'  => '\local_learningengagement\observer::assignment_submitted',
    ],
    [
        'eventname' => '\mod_forum\event\post_created',
        'callback'  => '\local_learningengagement\observer::forum_post_created',
    ],
];
