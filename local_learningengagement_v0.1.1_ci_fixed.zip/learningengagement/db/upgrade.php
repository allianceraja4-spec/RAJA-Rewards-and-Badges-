<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_learningengagement_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026072701) {
        $oldrules = new xmldb_table('local_le_rules');
        $newrules = new xmldb_table('local_learningengagement_rules');
        if ($dbman->table_exists($oldrules) && !$dbman->table_exists($newrules)) {
            $dbman->rename_table($oldrules, 'local_learningengagement_rules');
        }

        $oldtxn = new xmldb_table('local_le_txn');
        $newtxn = new xmldb_table('local_learningengagement_txn');
        if ($dbman->table_exists($oldtxn) && !$dbman->table_exists($newtxn)) {
            $dbman->rename_table($oldtxn, 'local_learningengagement_txn');
        }

        upgrade_plugin_savepoint(true, 2026072701, 'local', 'learningengagement');
    }

    return true;
}
