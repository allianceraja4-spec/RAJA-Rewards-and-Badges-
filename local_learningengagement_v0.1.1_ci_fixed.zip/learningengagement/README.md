# Learning Engagement Points — Moodle Local Plugin

Prototype V0.1 for Moodle 4.4+.

## Install
1. Unzip so the folder is exactly:
   `local/learningengagement`
2. Log in as Moodle administrator.
3. Visit Site administration > Notifications and complete the database upgrade.
4. Go to Site administration > Plugins > Local plugins > Learning Engagement Rules.
5. Click **Create default scoring rules**.
6. Create a test course, enrol a test learner, and test course views, module views, assignment submissions and forum posts.
7. Learners can visit `/local/learningengagement/index.php` to see points.

## Implemented in V0.1
- Course access: 5 points, first access per course.
- Generic module/lesson access: 10 points, first view per course module.
- Assignment submission: 25 points, protected from duplicate award for the same event object.
- Forum post: 12 points per unique post.
- Rules table containing all 15 requested activities.
- Learner transaction/points page.

## Not yet implemented
Quiz classification, module assessment logic, top-10% calculation, seven-day streak,
attendance integration, video watch percentage, peer communication, syllabus detection,
digital library integration, profile completion, editable rule form, faculty dashboard,
leaderboard and analytics.

This is an ALPHA development prototype. Test on a local/staging Moodle installation,
not a production university LMS.

## V0.1.1 CI fix
- XMLDB table names now use the required `local_learningengagement_` prefix.
- Added `db/upgrade.php` for existing V0.1 installations.
