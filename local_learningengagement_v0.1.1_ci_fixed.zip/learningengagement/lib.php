<?php
defined('MOODLE_INTERNAL') || die();

function local_learningengagement_extend_navigation(global_navigation $navigation) {
    if (isloggedin() && !isguestuser()) {
        $navigation->add(
            get_string('pluginname', 'local_learningengagement'),
            new moodle_url('/local/learningengagement/index.php'),
            navigation_node::TYPE_CUSTOM
        );
    }
}
