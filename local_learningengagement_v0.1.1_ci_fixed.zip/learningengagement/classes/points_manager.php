<?php
namespace local_learningengagement;

defined('MOODLE_INTERNAL') || die();

class points_manager {
    public static function award(int $userid, int $courseid, string $rulecode, int $objectid = 0): bool {
        global $DB;

        if (!$userid || isguestuser($userid)) {
            return false;
        }

        $rule = $DB->get_record('local_learningengagement_rules', ['code' => $rulecode, 'enabled' => 1]);
        if (!$rule) {
            return false;
        }

        $key = $rulecode . ':' . $userid . ':' . $courseid . ':' . $objectid;
        if ($DB->record_exists('local_learningengagement_txn', ['uniquekey' => $key])) {
            return false;
        }

        $record = (object)[
            'userid' => $userid,
            'courseid' => $courseid,
            'rulecode' => $rulecode,
            'objectid' => $objectid,
            'points' => $rule->points,
            'uniquekey' => $key,
            'timecreated' => time(),
        ];
        $DB->insert_record('local_learningengagement_txn', $record);
        return true;
    }
}
