<?php
namespace local_learningengagement;

defined('MOODLE_INTERNAL') || die();

class observer {
    public static function course_viewed(\core\event\course_viewed $event): void {
        points_manager::award($event->userid, $event->courseid, 'course_access', $event->courseid);
    }

    public static function module_viewed(\core\event\course_module_viewed $event): void {
        // V1 generic module view. Later we can map module types to Lesson/Material/Video rules.
        points_manager::award($event->userid, $event->courseid, 'lesson_access', (int)$event->contextinstanceid);
    }

    public static function assignment_submitted(\mod_assign\event\assessable_submitted $event): void {
        points_manager::award($event->userid, $event->courseid, 'assignment_submission', (int)$event->objectid);
    }

    public static function forum_post_created(\mod_forum\event\post_created $event): void {
        points_manager::award($event->userid, $event->courseid, 'forum_participation', (int)$event->objectid);
    }
}
